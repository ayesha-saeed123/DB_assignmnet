﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _2021_CE_12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Form1_Load() called...");
            richTextBox1.Text = "Startup...";
            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-54LU4UF\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True"))
                {
                    connection.Open();
                    richTextBox1.Text = "Connection Successful";
                }
            }
            catch (Exception ex)
            {
                richTextBox1.Text = "Error: " + ex.Message;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-54LU4UF\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True"))
            {
                connection.Open();
                richTextBox1.Text = "Inserting Record...";
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "INSERT INTO Customers (CustomerID, CompanyName) VALUES (@CustomerID, @CompanyName)";
                    command.Parameters.AddWithValue("@CustomerID", textBox1.Text);
                    command.Parameters.AddWithValue("@CompanyName", textBox2.Text);
                    command.ExecuteNonQuery();
                }
                richTextBox1.Text = "Record Inserted...";
            }
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-54LU4UF\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True"))
            {
                connection.Open();
                richTextBox1.Text = "Counting Records...";
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "SELECT COUNT(*) FROM Customers";
                    int count = (int)command.ExecuteScalar();
                    richTextBox1.Text = "Number of records: " + count;
                }
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-54LU4UF\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True"))
            {
                connection.Open();
                richTextBox1.Text = "Retrieving Records...";
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "SELECT * FROM Customers";
                    SqlDataAdapter da = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                    richTextBox1.Text = "Retrieval Successful!";
                }
            }
        }
    }
}
